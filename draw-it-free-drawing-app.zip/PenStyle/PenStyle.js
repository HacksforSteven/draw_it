/* eslint-disable require-yield, eqeqeq */

import {
  Sprite,
  Trigger,
  Watcher,
  Costume,
  Color,
  Sound
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

export default class PenStyle extends Sprite {
  constructor(...args) {
    super(...args);

    this.costumes = [
      new Costume("1", "./PenStyle/costumes/1.svg", { x: 234.5, y: -98.25 }),
      new Costume("-1", "./PenStyle/costumes/-1.svg", { x: 234.5, y: -98.25 })
    ];

    this.sounds = [new Sound("pop", "./PenStyle/sounds/pop.wav")];

    this.triggers = [
      new Trigger(Trigger.CLICKED, this.whenthisspriteclicked),
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked),
      new Trigger(
        Trigger.KEY_PRESSED,
        { key: "space" },
        this.whenKeySpacePressed
      )
    ];
  }

  *whenthisspriteclicked() {
    this.costumeNumber += 1;
    this.broadcast("change pen syle");
  }

  *whenGreenFlagClicked() {
    yield* this.wait(0);
    this.costume = -1;
  }

  *whenKeySpacePressed() {
    this.costumeNumber += 1;
  }
}
