/* eslint-disable require-yield, eqeqeq */

import {
  Stage as StageBase,
  Trigger,
  Watcher,
  Costume,
  Color,
  Sound
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

export default class Stage extends StageBase {
  constructor(...args) {
    super(...args);

    this.costumes = [
      new Costume("backdrop1", "./Stage/costumes/backdrop1.svg", {
        x: 240,
        y: 180
      })
    ];

    this.sounds = [new Sound("pop", "./Stage/sounds/pop.wav")];

    this.triggers = [];

    this.vars.color = 0;
    this.vars.saturation = 100;
    this.vars.brightness = 100;
    this.vars.size = 5;
    this.vars.smoothness = 10;
    this.vars.device = -1;

    this.watchers.color = new Watcher({
      label: "Color",
      style: "slider",
      visible: true,
      value: () => this.vars.color,
      setValue: value => {
        this.vars.color = value;
      },
      x: 240,
      y: 180
    });
    this.watchers.saturation = new Watcher({
      label: "Saturation",
      style: "slider",
      visible: true,
      value: () => this.vars.saturation,
      setValue: value => {
        this.vars.saturation = value;
      },
      x: 240,
      y: 141
    });
    this.watchers.brightness = new Watcher({
      label: "Brightness",
      style: "slider",
      visible: true,
      value: () => this.vars.brightness,
      setValue: value => {
        this.vars.brightness = value;
      },
      x: 240,
      y: 102
    });
    this.watchers.size = new Watcher({
      label: "Size",
      style: "slider",
      visible: true,
      value: () => this.vars.size,
      setValue: value => {
        this.vars.size = value;
      },
      x: 240,
      y: 63
    });
    this.watchers.smoothness = new Watcher({
      label: "Smoothness",
      style: "slider",
      visible: true,
      value: () => this.vars.smoothness,
      setValue: value => {
        this.vars.smoothness = value;
      },
      x: 240,
      y: 24
    });
  }
}
