import { Project } from "https://unpkg.com/leopard@^1/dist/index.esm.js";

import Stage from "./Stage/Stage.js";
import Pen from "./Pen/Pen.js";
import SampleColor from "./SampleColor/SampleColor.js";
import Device from "./Device/Device.js";
import PenStyle from "./PenStyle/PenStyle.js";
import Canvend from "./Canvend/Canvend.js";

const stage = new Stage({ costumeNumber: 1 });

const sprites = {
  Pen: new Pen({
    x: 116.41039130085721,
    y: -24.416642087812544,
    direction: 90,
    costumeNumber: 1,
    size: 100,
    visible: false,
    layerOrder: 5
  }),
  SampleColor: new SampleColor({
    x: -81,
    y: 163,
    direction: 90,
    costumeNumber: 1,
    size: 21.73913043478261,
    visible: true,
    layerOrder: 2
  }),
  Device: new Device({
    x: -1.4669189453125,
    y: 2.360870361328125,
    direction: 90,
    costumeNumber: 1,
    size: 100,
    visible: true,
    layerOrder: 3
  }),
  PenStyle: new PenStyle({
    x: -0.8482238601855556,
    y: 77.8102955340272,
    direction: 90,
    costumeNumber: 2,
    size: 100,
    visible: true,
    layerOrder: 4
  }),
  Canvend: new Canvend({
    x: 0,
    y: 0,
    direction: 90,
    costumeNumber: 1,
    size: 100,
    visible: true,
    layerOrder: 1
  })
};

const project = new Project(stage, sprites, {
  frameRate: 30 // Set to 60 to make your project run faster
});
export default project;
