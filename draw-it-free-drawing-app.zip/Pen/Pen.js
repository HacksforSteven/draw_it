/* eslint-disable require-yield, eqeqeq */

import {
  Sprite,
  Trigger,
  Watcher,
  Costume,
  Color,
  Sound
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

export default class Pen extends Sprite {
  constructor(...args) {
    super(...args);

    this.costumes = [
      new Costume("Pencil", "./Pen/costumes/Pencil.svg", {
        x: 0.125,
        y: 29.933323133324222
      }),
      new Costume("Eraser", "./Pen/costumes/Eraser.svg", {
        x: 0.27884615384610356,
        y: 29.85640364633801
      })
    ];

    this.sounds = [new Sound("pop", "./Pen/sounds/pop.wav")];

    this.triggers = [
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked),
      new Trigger(
        Trigger.KEY_PRESSED,
        { key: "space" },
        this.whenKeySpacePressed
      ),
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked2),
      new Trigger(
        Trigger.BROADCAST,
        { name: "change pen syle" },
        this.whenIReceiveChangePenSyle
      )
    ];

    this.vars.penSize = 5.2419392333365336;
  }

  *whenGreenFlagClicked() {
    this.stage.vars.brightness = 0;
    this.stage.vars.color = 0;
    this.stage.vars.saturation = 100;
    this.stage.vars.size = 1;
    this.stage.vars.brightness = 0;
    this.stage.vars.device = 1;
    this.clearPen();
    while (true) {
      if (this.stage.vars.device == 1) {
        this.visible = true;
        this.goto(
          this.x + (this.mouse.x - this.x) / this.stage.vars.smoothness,
          this.y + (this.mouse.y - this.y) / this.stage.vars.smoothness
        );
        if (this.mouse.down) {
          this.penDown = true;
        } else {
          this.penDown = false;
        }
      } else {
        if (this.mouse.down) {
          this.visible = true;
          this.vars.penSize = this.stage.vars.size;
          this.goto(this.mouse.x, this.mouse.y);
          yield* this.wait(0);
          while (!!this.mouse.down) {
            this.goto(
              this.x + (this.mouse.x - this.x) / this.stage.vars.smoothness,
              this.y + (this.mouse.y - this.y) / this.stage.vars.smoothness
            );
            this.penDown = true;
            yield;
          }
        } else {
          this.penDown = false;
          this.visible = false;
        }
      }
      yield;
    }
  }

  *whenKeySpacePressed() {
    this.costumeNumber += 1;
  }

  *whenGreenFlagClicked2() {
    while (true) {
      if (this.costume.name == "Eraser") {
        this.penColor.h = 0;
        this.penColor.s = 0;
        this.penColor.v = 100;
      } else {
        this.penColor.h = this.stage.vars.color;
        this.penColor.s = this.stage.vars.saturation;
        this.penColor.v = this.stage.vars.brightness;
      }
      this.penSize = this.vars.penSize;
      this.vars.penSize +=
        (this.stage.vars.size +
          Math.hypot(this.mouse.x - this.x, this.mouse.y - this.y) / 10 -
          this.vars.penSize) /
        10;
      yield;
    }
  }

  *whenIReceiveChangePenSyle() {
    this.costumeNumber += 1;
  }
}
