/* eslint-disable require-yield, eqeqeq */

import {
  Sprite,
  Trigger,
  Watcher,
  Costume,
  Color,
  Sound
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

export default class SampleColor extends Sprite {
  constructor(...args) {
    super(...args);

    this.costumes = [
      new Costume("costume1", "./SampleColor/costumes/costume1.svg", {
        x: 11.5,
        y: 11.5
      })
    ];

    this.sounds = [new Sound("pop", "./SampleColor/sounds/pop.wav")];

    this.triggers = [
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked)
    ];
  }

  *whenGreenFlagClicked() {
    while (true) {
      this.effects.color = this.stage.vars.color * 2;
      this.effects.brightness = this.stage.vars.brightness + -100;
      this.effects.ghost = this.stage.vars.saturation * -1 + 100;
      this.size = this.stage.vars.size * 3;
      yield;
    }
  }
}
